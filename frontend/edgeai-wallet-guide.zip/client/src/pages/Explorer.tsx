import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import { Activity, Box, Clock, Database, Hash, Layers, ArrowLeft, RefreshCw } from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "wouter";

// Types based on the blockchain API
interface Block {
  index: number;
  timestamp: number;
  proof: number;
  previous_hash: string;
  transactions: Transaction[];
  validator: string;
  hash: string;
  entropy: number;
}

interface Transaction {
  id: string;
  sender: string;
  recipient: string;
  amount: number;
  timestamp: number;
  signature?: string;
  data?: string;
  data_hash?: string;
}

interface ChainInfo {
  length: number;
  total_transactions: number;
  total_accounts: number;
  difficulty: number;
  blockchain_id: string;
}

const API_URL = "https://edgeai-blockchain-node.fly.dev/api";

export default function Explorer() {
  const [chainInfo, setChainInfo] = useState<ChainInfo | null>(null);
  const [blocks, setBlocks] = useState<Block[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());

  const fetchData = async () => {
    try {
      setLoading(true);
      // Fetch chain info
      const infoRes = await fetch(`${API_URL}/chain`);
      const infoData = await infoRes.json();
      setChainInfo(infoData);

      // Fetch blocks (reverse order to show newest first)
      const blocksRes = await fetch(`${API_URL}/blocks`);
      const blocksData = await blocksRes.json();
      // Sort by index descending
      setBlocks(blocksData.sort((a: Block, b: Block) => b.index - a.index));
      
      setLastUpdated(new Date());
    } catch (error) {
      console.error("Failed to fetch blockchain data", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    // Auto-refresh every 10 seconds
    const interval = setInterval(fetchData, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground p-6 md:p-12 font-mono selection:bg-primary selection:text-primary-foreground">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Link href="/">
                <a className="p-2 hover:bg-muted rounded-full transition-colors">
                  <ArrowLeft className="w-5 h-5 text-muted-foreground" />
                </a>
              </Link>
              <h1 className="text-3xl font-bold tracking-tighter text-primary">
                EdgeAI Explorer
              </h1>
            </div>
            <p className="text-muted-foreground pl-11">
              Real-time blockchain surveillance system.
            </p>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Clock className="w-3 h-3" />
              <span>Updated: {lastUpdated.toLocaleTimeString()}</span>
            </div>
            <button 
              onClick={fetchData}
              disabled={loading}
              className={cn(
                "p-2 rounded-md border border-border bg-card hover:bg-accent transition-all",
                loading && "opacity-50 cursor-not-allowed"
              )}
            >
              <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
            </button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatsCard 
            title="Block Height" 
            value={chainInfo?.length.toString() || "-"} 
            icon={<Layers className="w-4 h-4 text-blue-400" />}
            loading={loading}
          />
          <StatsCard 
            title="Total Transactions" 
            value={chainInfo?.total_transactions.toString() || "-"} 
            icon={<Activity className="w-4 h-4 text-green-400" />}
            loading={loading}
          />
          <StatsCard 
            title="Active Accounts" 
            value={chainInfo?.total_accounts.toString() || "-"} 
            icon={<Hash className="w-4 h-4 text-purple-400" />}
            loading={loading}
          />
          <StatsCard 
            title="Network Difficulty" 
            value={chainInfo?.difficulty.toString() || "-"} 
            icon={<Database className="w-4 h-4 text-orange-400" />}
            loading={loading}
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Blocks List */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <Box className="w-5 h-5 text-primary" />
                Latest Blocks
              </h2>
              <Badge variant="outline" className="font-mono">
                {blocks.length} Total
              </Badge>
            </div>
            
            <ScrollArea className="h-[600px] rounded-lg border border-border bg-card/50 backdrop-blur-sm">
              <div className="p-4 space-y-4">
                {blocks.map((block) => (
                  <BlockCard key={block.hash} block={block} />
                ))}
              </div>
            </ScrollArea>
          </div>

          {/* Recent Transactions (Flattened from blocks) */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <Activity className="w-5 h-5 text-primary" />
                Recent Activity
              </h2>
            </div>
            
            <ScrollArea className="h-[600px] rounded-lg border border-border bg-card/50 backdrop-blur-sm">
              <div className="p-4 space-y-4">
                {blocks.flatMap(b => b.transactions).slice(0, 20).map((tx) => (
                  <TransactionCard key={tx.id} tx={tx} />
                ))}
                {blocks.flatMap(b => b.transactions).length === 0 && (
                  <div className="text-center text-muted-foreground py-8">
                    No transactions found
                  </div>
                )}
              </div>
            </ScrollArea>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatsCard({ title, value, icon, loading }: { title: string, value: string, icon: React.ReactNode, loading: boolean }) {
  return (
    <Card className="bg-card/50 backdrop-blur-sm border-border">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className={cn("text-2xl font-bold font-mono", loading && "opacity-50")}>
          {value}
        </div>
      </CardContent>
    </Card>
  );
}

function BlockCard({ block }: { block: Block }) {
  return (
    <div className="group relative rounded-lg border border-border bg-card p-4 hover:bg-accent/50 transition-all">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-lg font-bold text-primary">#{block.index}</span>
            <span className="text-xs text-muted-foreground font-mono truncate max-w-[100px] md:max-w-[200px]">
              {block.hash}
            </span>
          </div>
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <span>Tx: {block.transactions.length}</span>
            <span>Validator: {block.validator.substring(0, 8)}...</span>
            <span>Entropy: {block.entropy.toFixed(4)}</span>
          </div>
        </div>
        <div className="text-right">
          <div className="text-xs text-muted-foreground">
            {new Date(block.timestamp).toLocaleString()}
          </div>
          <Badge variant="secondary" className="mt-1 text-[10px]">
            Proof: {block.proof}
          </Badge>
        </div>
      </div>
    </div>
  );
}

function TransactionCard({ tx }: { tx: Transaction }) {
  const isData = !!tx.data;
  
  return (
    <div className="rounded-lg border border-border bg-card p-3 text-sm hover:border-primary/50 transition-colors">
      <div className="flex justify-between items-start mb-2">
        <Badge variant={isData ? "default" : "outline"} className="text-[10px]">
          {isData ? "DATA" : "TRANSFER"}
        </Badge>
        <span className="text-[10px] text-muted-foreground">
          {new Date(tx.timestamp).toLocaleTimeString()}
        </span>
      </div>
      
      <div className="space-y-1 font-mono text-xs">
        <div className="flex justify-between">
          <span className="text-muted-foreground">From:</span>
          <span className="truncate max-w-[120px]">{tx.sender}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-muted-foreground">To:</span>
          <span className="truncate max-w-[120px]">{tx.recipient}</span>
        </div>
        
        <Separator className="my-2" />
        
        {isData ? (
          <div className="bg-muted/50 p-2 rounded text-[10px] break-all">
            {tx.data}
          </div>
        ) : (
          <div className="flex justify-between items-center font-bold text-primary">
            <span>Amount:</span>
            <span>{tx.amount} EDGE</span>
          </div>
        )}
      </div>
    </div>
  );
}
